const axios = require('axios');


const consultaNomesAPI = async ( nome ) => {
    console.log("Cheguei aqui..." + nome)

    //MONTAR A URL DE CONSULTA
    const URL1 = `https://api.agify.io/?name=${nome}`
    const URL2 = `https://api.genderize.io/?name=${nome}`
    const URL3 = `https://api.nationalize.io/?name=${nome}`
    
    //CHAMADA HTTP
    try {
        const respostaIdade = await axios.get(URL1);
        const respostaGenero = await axios.get(URL2);
        const respostaPais = await axios.get(URL3);

        //RETORNAR
        return {
            idade: respostaIdade.data.age,
            genero: respostaGenero.data.gender,
            pais: respostaPais.data.country
        };
    } catch (error) {
        console.log({ error });
        return null;
    }
}

module.exports = { consultaNomesAPI };