const { consultaNomesAPI } = require("../api-nomes/consulta-nome");
const { Router } = require('express');

class NomesController {
    constructor() {

    }
    async detalhar(req, res){
    const { nome } = req.body;
    // VERIFICAR SE OS DADOS DO NOME ESTAO DE ACORDO COM O NECESSARIO PARA A API
        if (nome.search(1) != -1 || 
            nome.search(2) != -1 || 
            nome.search(3) != -1 || 
            nome.search(4) != -1 || 
            nome.search(5) != -1 || 
            nome.search(6) != -1 || 
            nome.search(7) != -1 || 
            nome.search(8) != -1 || 
            nome.search(9) != -1 || 
            nome.search(0) != -1 || 
            nome.value == ""){
        console.log('Erro! Por favor digite um nome válido!');
        return res.send("ooops,  nao consegui cadastrar ");
    }
    
    

    const pessoa = await consultaNomesAPI(nome);
    if (pessoa) {
        // TODO RENDER COM EJS
        console.log({ pessoa })
        return res.render('detalhe',  { pessoa: pessoa });
    }

    }
};





module.exports = { NomesController }