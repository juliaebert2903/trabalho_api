const express = require("express");
const axios = require('axios');
const { consultaNomesAPI } = require("./api-nomes/consulta-nome");
const app = express();

app.set('view engine', 'ejs');
app.set('views', './src/views');

app.use(express.static('public'));

app.use(express.urlencoded());

const { NomesController } = require('./controllers/nome-controllers');
const controller = new NomesController();
app.post('/detalhar', controller.detalhar);

app.get('/', async (req, res) => {
    const urlBusca = `https://api.agify.io/?name=${nome}`; 

    try {
        const responseApi = await axios.get(urlBusca);

        res.send({
            urlBusca,
            statusBusca: responseApi.status,
            dataBusca: responseApi.data
        });
    } catch (error) {
        console.log({error})
        if (error.response.status == 404)
            res.send('NAO FOI POSSIVEL LOCALIZAR O RECURSO NA API');
        else
            res.send('ERRO DESCONHECIDO...');
    }
    
});

app.listen(3000, () => console.log("Escutando na porta 3000"));